library(rsconnect)

deployApp(appFiles = NULL,
          account = "srgexpert",
          forceUpdate = TRUE)
