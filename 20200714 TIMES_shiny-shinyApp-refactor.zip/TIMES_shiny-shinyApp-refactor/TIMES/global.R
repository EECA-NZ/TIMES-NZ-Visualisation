load("data/data_for_shiny.rda")
# the data for charting must be saved in rda formation
# the rda file must contain two data frams: combined_df (charting data) and measure_list (list of measures for main drop-down menu)
